<?php // Example 26-8: profile.php
require_once 'header.php';

if (!$loggedin) die("You have been logged out <a href='index.php'>click here </a> to login");
echo "<section><div class='main'><h3> Welcome  ". $user."!</h3></section>";
?>
<html>
	<head>
		<title>Grad-Bevy</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
    </head>
    <body>
    	<section id="banner">
			<div class="inner">
				<h1>Grad-Bevy:<span>COLLEGE SOCIAL NETWORK </br></span></h1>	
				<h2>Great Stories Begin Here!</h2>
				<h3><strong>Think, Explore and Meet your peers</strong></h3>
			</div>
        </section>
		<section id="bannera">
			<!-- <div> -->
				<header>
					<h2>Academic Calender</h2>
				</header>
				<ul class="actions">
					<li><a href="academiccal.pdf" class="button alt"><font color="#330033">Click here</font></a><strong>to view the academic calender</strong></li>
				</ul>
			<!-- </div> -->
		</section>