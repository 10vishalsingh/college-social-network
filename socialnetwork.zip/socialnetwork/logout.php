<?php // Example 26-12: logout.php
require_once 'header.php';

if (isset($_SESSION['user'])) {
    destroySession();
    echo "<div class='main'>You have been logged out. Please " .
        "<a href='index.php'>click here</a> to login.";
} else echo "<div class='main'><br>" .
    "You have already been logged out.".
    "a href='href='index.php>click here</a> to login again";
?>

<br><br></div>
</body>
</html>
