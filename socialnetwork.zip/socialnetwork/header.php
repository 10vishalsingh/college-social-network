<?php // Example 26-2: header.php
session_start();

echo "<!DOCTYPE html>\n<html><head>";

require_once 'functions.php';

$userstr = ' (Guest)';

if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];
    $loggedin = TRUE;
    $userstr = " ($user)";
} else $loggedin = FALSE;
?>
    
<head>
    <title>Gradbevy</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="assets/css/main.css" />
    <script src='javascript.js'></script>
    <script src='/js/bootstrap.js'></script>
    <link rel='stylesheet' href='/css/bootstrap.css' type='text/css'>
</head>

<?php

if ($loggedin) {
?>
<body>

<!-- Header -->
    <header id="header">
        <div class="inner">
            <a href="header.php" class="logo">Grad Bevy</a>
            
               <a href='home.php'>Home</a>
               <a href='profile.php'>Profile</a>
               <a href='messages.php'>Messages</a>
               <a href='friends.php'>Friends</a>
               <a href='members.php'>Members</a>
               <a href='logout.php'>Log out</a>
          
        </div>
    </header>
   
            <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

<?php


} else {
    
}
?>
